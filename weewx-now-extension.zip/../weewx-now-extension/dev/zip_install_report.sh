zip -r ../weewx-now-extension.zip ../weewx-now-extension/
sudo weectl extension uninstall now
#rem sudo weectl extension install ../weewx-now-extension.zip
#rem sudo weectl extension /etc/weewx/weewx.conf